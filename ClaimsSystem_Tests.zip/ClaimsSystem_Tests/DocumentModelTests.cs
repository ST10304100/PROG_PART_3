﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PROG_PART_2.Models;

namespace ClaimsSystem_Tests
{
    [TestFixture]
    public class DocumentTests
    {
        [Test]
        public void Document_ValidProperties_ShouldBeValid()
        {
            var document = new Document
            {
                DocumentName = "Test Document",
                FilePath = "C:/Users/jorda/source/repos/PROG_PART_2/wwwroot/documents/6c7ed004-ecec-48d4-a6a8-7304bee1f826_TestDoc.pdf",
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            var validationResults = ValidateModel(document);

            Assert.IsEmpty(validationResults);
        }

        [Test]
        public void Document_EmptyDocumentName_ShouldBeInvalid()
        {
            var document = new Document
            {
                DocumentName = string.Empty,
                FilePath = "C:/Users/jorda/source/repos/PROG_PART_2/wwwroot/documents/6c7ed004-ecec-48d4-a6a8-7304bee1f826_TestDoc.pdf",
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            var validationResults = ValidateModel(document);

            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("Document Name is required.", validationResults[0].ErrorMessage);
        }

        [Test]
        public void Document_EmptyFilePath_ShouldBeInvalid()
        {
            var document = new Document
            {
                DocumentName = "Test Document",
                FilePath = string.Empty,
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            var validationResults = ValidateModel(document);

            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("File Path is required.", validationResults[0].ErrorMessage);
        }

        [Test]
        public void Document_ExceededDocumentNameMaxLength_ShouldBeInvalid()
        {
            var document = new Document
            {
                DocumentName = new string('A', 256),
                FilePath = "C:/Documents/TestDocument.pdf",
                UploadedOn = DateTime.Now,
                ClaimId = 1
            };

            var validationResults = ValidateModel(document);

            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("The field DocumentName must be a string or array type with a maximum length of '255'.", validationResults[0].ErrorMessage);
        }

        private IList<ValidationResult> ValidateModel(Document document)
        {
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(document);
            Validator.TryValidateObject(document, validationContext, validationResults, true);
            return validationResults;
        }
    }
}
