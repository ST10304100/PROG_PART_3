﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Moq;
using PROG_PART_2.Controllers;
using PROG_PART_2.Data;

namespace ClaimsSystem_Tests
{
    [TestFixture]
    public class ClaimControllerTests
    {
        private ClaimController _controller;
        private ApplicationDBContext _context;
        private UserManager<IdentityUser> _userManager;
        private IdentityUser _testUser;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<ApplicationDBContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase" + Guid.NewGuid().ToString())
                .Options;

            _context = new ApplicationDBContext(options);
            _userManager = CreateUserManager();

            _testUser = new IdentityUser
            {
                Id = Guid.NewGuid().ToString(),
                UserName = "testuser@example.com"
            };

            _context.Users.Add(_testUser);
            _context.SaveChanges();

            _controller = new ClaimController(_context, _userManager, null);
        }

        [TearDown]
        public void Dispose()
        {
            _context?.Dispose();
            _controller?.Dispose();
            _userManager?.Dispose();
        }

        [Test]
        public void IsValidPdfDocument_ValidPdf_ReturnsTrue()
        {
            var validFile = new FormFile(new MemoryStream(new byte[100]), 0, 100, "Data", "valid.pdf")
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/pdf"
            };

            var result = _controller.IsValidDocument(validFile);
            Assert.IsTrue(result);
        }

        [Test]
        public void IsValidPdfDocument_InvalidPdf_ReturnsFalse()
        {
            var invalidFile = new FormFile(new MemoryStream(new byte[100]), 0, 100, "Data", "invalid.txt")
            {
                Headers = new HeaderDictionary(),
                ContentType = "text/plain"
            };

            var result = _controller.IsValidDocument(invalidFile);
            Assert.IsFalse(result);
        }

        [Test]
        public void IsValidPdfDocument_FileTooLarge_ReturnsFalse()
        {
            var largeFile = new FormFile(new MemoryStream(new byte[20 * 1024 * 1024]), 0, 20 * 1024 * 1024, "Data", "large.pdf")
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/pdf"
            };

            var result = _controller.IsValidDocument(largeFile);
            Assert.IsFalse(result);
        }

        private UserManager<IdentityUser> CreateUserManager()
        {
            var store = new Mock<IUserStore<IdentityUser>>();
            var userManager = new UserManager<IdentityUser>(
                store.Object,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
            );

            return userManager;
        }


    }
}
