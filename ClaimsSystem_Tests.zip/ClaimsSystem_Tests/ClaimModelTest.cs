﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PROG_PART_2.Models;

namespace ClaimsSystem_Tests
{
    [TestFixture]
    public class ClaimModelTests
    {
        [Test]
        public void ValidClaim_ShouldNotHaveValidationErrors()
        {
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 200,
                TotalAmount = 1000,
                Notes = "This is a valid claim.",
                DateSubmitted = DateTime.Now
            };

            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            Assert.IsTrue(isValid);
            Assert.IsEmpty(validationResults);
        }

        [Test]
        public void Claim_WithInvalidHoursWorked_ShouldHaveValidationErrors()
        {
            var claim = new Claim
            {
                HoursWorked = 0,
                HourlyRate = 100,
                TotalAmount = 1000,
                Notes = "Invalid claim due to hours worked.",
                DateSubmitted = DateTime.Now
            };

            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hourly Rate must be between 50 and 1000."));
        }

        [Test]
        public void Claim_WithInvalidHourlyRate_ShouldHaveValidationErrors()
        {
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 40,
                TotalAmount = 400,
                Notes = "Invalid claim due to hourly rate.",
                DateSubmitted = DateTime.Now
            };

            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hourly Rate must be between 50 and 1000."));
        }

        [Test]
        public void Claim_WithFutureDateSubmitted_ShouldHaveValidationErrors()
        {
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 100,
                TotalAmount = 1000,
                Notes = "This claim has a future submission date.",
                DateSubmitted = DateTime.Now.AddDays(1)
            };

            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Date Submitted cannot be in the future."));
        }

        [Test]
        public void Claim_WithDateNotInCurrentOrPreviousMonth_ShouldHaveValidationErrors()
        {
            var claim = new Claim
            {
                HoursWorked = 10,
                HourlyRate = 100,
                TotalAmount = 1000,
                Notes = "Invalid submission date.",
                DateSubmitted = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 2, 1)
            };

            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Date Submitted can only be from the current month or previous month."));
        }
    }
}
